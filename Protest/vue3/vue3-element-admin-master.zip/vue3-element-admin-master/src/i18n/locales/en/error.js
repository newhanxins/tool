export default {
  noauth: 'No access',
  servererror: 'Server error',
  notfound: 'Page not found',
  backhome: 'Back to Home',
}
