export default {
  refresh: 'Refresh',
  close: 'Close',
  other: 'Close other',
  left: 'Close left',
  right: 'Close right',
  all: 'Close all',
}
