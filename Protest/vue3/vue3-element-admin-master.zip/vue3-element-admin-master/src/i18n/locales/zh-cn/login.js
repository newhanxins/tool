export default {
  username: '用户名',
  password: '密码',
  login: '登录',
  logining: '登录中...',
  loginsuccess: '登录成功',
  'rules-username': '请输入用户名',
  'rules-password': '请输入密码',
  'rules-regpassword': '长度在 6 到 12 个字符',
}
