export default {
  refresh: '刷新',
  close: '关闭',
  other: '关闭其它',
  left: '关闭左侧',
  right: '关闭右侧',
  all: '关闭全部',
}
