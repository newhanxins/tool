export default {
  noauth: '您无权访问此页面',
  servererror: '服务器出错了',
  notfound: '您访问的页面不存在',
  backhome: '返回首页',
}
