# 小米 SU7 网站特效解析 demo

demo 地址：https://su7-replica.netlify.app/

demo（芙宁娜版）地址：https://su7-replica.netlify.app/#furina

原网站地址：https://gamemcu.com/su7/

## 食用方法

安装依赖

```sh
npm i
```

本地调试

```sh
npm run dev
```

构建

```sh
npm run build
```

预览

```sh
npm run preview
```
