declare module "*.glsl" {
  const value: string;
  export default value;
}
