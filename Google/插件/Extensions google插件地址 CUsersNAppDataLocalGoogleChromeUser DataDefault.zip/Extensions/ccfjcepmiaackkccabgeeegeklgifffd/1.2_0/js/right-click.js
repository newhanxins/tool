/**
 * @file 右键翻译菜单,暂不需要
 */

// var title = '翻译';
// var id = chrome.contextMenus.create({"title": title, "contexts":['page'],
//                                       "onclick": genericOnClick});