/* Kumquat Hub Background Render
 * 
 **/

(function (undefined) {

    pl.extend(ke.app.render, {
        organize: {},
        events: {}
    });

})();