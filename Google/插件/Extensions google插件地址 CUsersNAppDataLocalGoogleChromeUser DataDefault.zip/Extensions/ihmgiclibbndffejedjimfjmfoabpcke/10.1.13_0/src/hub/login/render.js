/* Kumquat Hub HT Render
 * 
 **/

(function (undefined) {

    pl.extend(ke.app.render, {
        organize: {
        },

        events: {}
    });

})();